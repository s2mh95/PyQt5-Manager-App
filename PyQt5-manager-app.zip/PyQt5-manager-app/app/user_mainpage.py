import sys

from PyQt5.QtWidgets import *


class userpage(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('part.co')
        self.setGeometry(200,150,1100,700)
        self.UI()
        self.show()
        
    def UI(self):
        self.widgets()
        self.layouts()
        
    def widgets(self):
        pass
    
    def layouts(self):
        pass
    
def main():
    app = QApplication(sys.argv)
    win = userpage()
    sys.exit(app.exec_())
    
if __name__ == '__main__':
    main()