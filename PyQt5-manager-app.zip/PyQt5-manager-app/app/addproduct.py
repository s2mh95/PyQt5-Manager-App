import sqlite3
import sys
import admin_mainpage

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *

Connection = sqlite3.connect('DataBase.db')
Cursor = Connection.cursor()

class addproducts(QWidget):
    def __init__(self) :
        super().__init__()
        self.setWindowTitle('Add Product')
        self.setGeometry(500,200,300,550)
        self.UI()
        self.show()
    
    def UI(self):
        self.widgets()
        self.layouts()

    def widgets(self):
        self.setStyleSheet('font-size:14pt')
        self.header = QLabel('ADD PRODUCT')
        self.header.setStyleSheet('font-size:21pt')
        self.namelb = QLabel('Name :')
        self.pricelb = QLabel('Price :')
        self.quantitylb = QLabel('Quantity :')
        self.qualitylb = QLabel('Quality :')
        self.availabilitylb = QLabel('Availability :')
        self.nameentry = QLineEdit()
        self.nameentry.setPlaceholderText('Enter product name')
        self.priceentry = QLineEdit()
        self.priceentry.setPlaceholderText('Enter product price')
        self.quantityentry = QLineEdit()
        self.quantityentry.setPlaceholderText('Enter product quantity')
        self.qualityentry = QLineEdit()
        self.qualityentry.setPlaceholderText('Enter product quality')
        self.avabox = QComboBox()
        self.avabox.addItems(['Available', 'Unavailable'])
        self.addbtn = QPushButton('Add')
        self.addbtn.clicked.connect(self.save)
        self.closebtn = QPushButton('Close')
        self.closebtn.clicked.connect(self.closed)
        
    def layouts(self):
        self.Mlayout =QVBoxLayout()
        self.MTlayout = QHBoxLayout()
        self.MBlayout = QFormLayout()
        self.MTlayout.addWidget(self.header)
        self.MTlayout.setAlignment(Qt.AlignCenter)
        self.MBlayout.addRow(self.namelb,self.nameentry)
        self.MBlayout.addRow(self.pricelb,self.priceentry)
        self.MBlayout.addRow(self.quantitylb,self.quantityentry)
        self.MBlayout.addRow(self.qualitylb,self.qualityentry)
        self.MBlayout.addRow(self.availabilitylb,self.avabox)
        self.MBlayout.addRow(self.addbtn,self.closebtn)
        self.MBlayout.setVerticalSpacing(27)
        self.Mlayout.addLayout(self.MTlayout, 30)
        self.Mlayout.addLayout(self.MBlayout, 70)
        self.setLayout(self.Mlayout)
    
    def save(self):
        name = self.nameentry.text()
        price = self.priceentry.text()
        quantity = self.quantityentry.text()
        quality = self.qualityentry.text()
        status = self.avabox.currentText()
        query = 'INSERT INTO products (p_name, p_price, p_quantity, p_quality, p_availability) VALUES (?,?,?,?,?)'
        Cursor.execute(query, (name,price,quantity,quality,status))
        Connection.commit()
        QMessageBox.information(self, ' info', 'product added')
        self.nameentry.setText('')
        self.priceentry.setText('')
        self.quantityentry.setText('')
        self.qualityentry.setText('')
        
    def closed(self):
        self.newpage = admin_mainpage.adminpage()
        self.close()
    