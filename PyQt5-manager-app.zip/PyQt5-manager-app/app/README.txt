This is my app but it snot complete
please run it with steps below to see what i create with PyQt5 library and SQLite 

1. run the "login_page"
2. username = administrator   password = 1111
3.Done 

you can see the product menu and members menu and the service menu 
i was try to create an app for a companny that sell a device like printer and they had products to sell and 
monthly mantenance reports for devices they sell. 

its not complete and full of bugs but i will make it complete very soon . 