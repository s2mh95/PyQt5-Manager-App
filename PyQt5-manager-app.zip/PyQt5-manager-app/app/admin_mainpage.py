import sqlite3
import sys

from PyQt5.QtCore import QFileInfo
from PyQt5.QtGui import *
from PyQt5.QtPrintSupport import *
from PyQt5.QtWidgets import *

import add
import addproduct
import login_page

Connection = sqlite3.connect('DataBase.db')
Cursor = Connection.cursor()

def print_widget(widget, filename):
    printer = QPrinter(QPrinter.HighResolution)
    printer.setOutputFormat(QPrinter.PdfFormat)
    printer.setOutputFileName(filename)
    printer.setPageSize(QPrinter.A4)
    painter = QPainter(printer)
    # start scale
    xscale = printer.pageRect().width() * 1.0 / widget.width()
    yscale = printer.pageRect().height() * 1.0 / widget.height()
    scale = min(xscale, yscale)
    painter.translate(printer.paperRect().center())
    painter.scale(scale, scale)
    painter.translate(-widget.width() / 2, -widget.height() / 2)
    # end scale

    widget.render(painter)
    painter.end()
    
class adminpage(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Part.co')
        self.setGeometry(200,150,1100,700)
        self.UI()
        self.show()
        
    def UI(self):
        self.Tabs()
        self.widgets()
        self.layouts()
        self.displayproducts()
        self.companeyList()
        self.displaydate()
        self.displaymembers()
        
    def Tabs(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()
        self.tabs.addTab(self.tab1, 'Products')
        self.tabs.addTab(self.tab2, "Service's Report")
        self.tabs.addTab(self.tab3, 'Members')

    
    def widgets(self):
        #-----------------------------------------tab1-----------------------------------------
        self.ptable = QTableWidget()
        self.ptable.setColumnCount(6)
        self.ptable.setColumnHidden(0, True)
        columnlist1= ['Product ID','Name','Price','Quantity','Quality','availability']
        for i in range(self.ptable.columnCount()):
            self.ptable.setHorizontalHeaderItem(i, QTableWidgetItem(columnlist1[i]))
            self.ptable.horizontalHeader().setSectionResizeMode(i, QHeaderView.Stretch)
        self.psearchentry = QLineEdit()
        self.psearchentry.setPlaceholderText("Enter product's name")
        self.psearchbtn = QPushButton('Search')
        self.psearchbtn.clicked.connect(self.searchproduct)
        self.qualitylb = QLabel('Quality')
        self.qualitybox = QComboBox()
        self.qualitybox.addItems(['orginal', 'level 1', 's1', 'highcopy'])
        self.availablelb = QLabel('Available')
        self.availablebox = QComboBox()
        self.availablebox.addItems(['available', 'unavailable'])
        self.filterbtn = QPushButton('Filter')
        self.filterbtn.clicked.connect(self.filterp)
        self.resetbtn = QPushButton('Reset')
        self.resetbtn.clicked.connect(self.resetlist)
        self.addbtn = QPushButton('Add')
        self.addbtn.clicked.connect(self.addpage)
        self.printbtn = QPushButton('Print')
        self.printbtn.clicked.connect(self.printreport)
        self.logoutbtn = QPushButton('Logout')
        self.logoutbtn.clicked.connect(self.logout)
        #-----------------------------------------tab2-----------------------------------------
        self.companyname = QComboBox()
        self.companyname.addItem('--Company List--')
        self.companyname.currentTextChanged.connect(self.displaydate)
        self.ADDbtn = QPushButton('Add')
        self.ADDbtn.clicked.connect(self.newdevice)
        self.PRINTbtn = QPushButton('print')
        self.PRINTbtn.clicked.connect(self.preport)
        self.DELETEbtn = QPushButton('delete')
        self.DELETEbtn.clicked.connect(self.deletereport)
        self.datetable = QTableWidget()
        self.datetable.setColumnCount(5)
        self.datetable.setColumnHidden(0, True)
        columnlist2 = ['Report id','Date', 'Technician','Serial  number', 'Model']
        for i in range(self.datetable.columnCount()):
            self.datetable.setHorizontalHeaderItem(i, QTableWidgetItem(columnlist2[i]))
            self.datetable.horizontalHeader().setSectionResizeMode(i, QHeaderView.Stretch)
        self.datetable.clicked.connect(self.rowclick)
        self.reporttable = QTableWidget()
        self.reporttable.setColumnCount(2)
        self.reporttable.setColumnHidden(0, True)
        columnlist3 = ['Report id','Report']
        for i in range(self.reporttable.columnCount()):
            self.reporttable.setHorizontalHeaderItem(i, QTableWidgetItem(columnlist3[i]))
            self.reporttable.horizontalHeader().setSectionResizeMode(i, QHeaderView.Stretch)
        self.BW = QLabel()
        self.Color = QLabel()
        self.Total = QLabel()
        self.BL = QLabel()
        self.CL = QLabel()
        self.K = QLabel()
        self.C = QLabel()
        self.M = QLabel()
        self.Y = QLabel()
        self.R1= QLabel()
        self.R2 = QLabel()
        self.R3 = QLabel()
        self.R4 = QLabel() 
        self.kchip = QLabel()
        self.cchip = QLabel()
        self.mchip = QLabel()
        self.ychip = QLabel()
        self.r1chip = QLabel()
        self.r2chip = QLabel()
        self.r3chip = QLabel()
        self.r4chip = QLabel()
        #-----------------------------------------tab3-----------------------------------------
        self.membertable = QTableWidget()
        self.membertable.setColumnCount(5)
        self.membertable.setColumnHidden(0, True)
        columnlist4 = ['member id' , 'Name' , 'Password' , 'Phone number' , 'Job Title']
        for i in range(self.membertable.columnCount()):
            self.membertable.setHorizontalHeaderItem(i , QTableWidgetItem(columnlist4[i]))
            self.membertable.horizontalHeader().setSectionResizeMode(i , QHeaderView.Stretch)
        self.searchmemberentry = QLineEdit()
        self.searchmemberentry.setPlaceholderText("Enter Member's Name")
        self.shbtn = QPushButton('Search')
        self.shbtn.clicked.connect(self.searchmember)
        self.addmembers = QPushButton('Add')
        self.addmembers.clicked.connect(self.addmember)
        self.prntbtn = QPushButton('Print')
        self.prntbtn.clicked.connect(self.printmemberlist)
        self.Deletebtn = QPushButton('Delete')
        self.Deletebtn.clicked.connect(self.deletmember)
    
    def layouts(self):
        #-----------------------------------------tab1-----------------------------------------
        self.M1layout = QHBoxLayout()
        self.ML1layout = QHBoxLayout()
        self.MR1layout = QVBoxLayout()
        self.RT1layout = QHBoxLayout()
        self.RM1layout = QFormLayout()
        self.RB1layout = QHBoxLayout()
        self.ML1groupbox = QGroupBox("Product's List")
        self.RT1groupbox = QGroupBox('Search')
        self.RM1groupbox = QGroupBox('Filter')
        self.ML1layout.addWidget(self.ptable)
        self.RT1layout.addWidget(self.psearchentry)
        self.RT1layout.addWidget(self.psearchbtn)
        self.RM1layout.addRow(self.qualitylb, self.qualitybox)
        self.RM1layout.addRow(self.availablelb, self.availablebox)
        self.RM1layout.addRow(self.resetbtn, self.filterbtn)
        self.RB1layout.addWidget(self.addbtn)
        self.RB1layout.addWidget(self.printbtn)
        self.RB1layout.addWidget(self.logoutbtn)
        self.RT1groupbox.setLayout(self.RT1layout)
        self.RM1groupbox.setLayout(self.RM1layout)
        self.ML1groupbox.setLayout(self.ML1layout)
        self.MR1layout.addWidget(self.RT1groupbox, 20)
        self.MR1layout.addWidget(self.RM1groupbox, 60)
        self.MR1layout.addLayout(self.RB1layout, 20)
        self.M1layout.addWidget(self.ML1groupbox, 80)
        self.M1layout.addLayout(self.MR1layout, 20)
        self.tab1.setLayout(self.M1layout)
        #-----------------------------------------tab2-----------------------------------------
        self.M2layout = QHBoxLayout()
        self.ML2layout = QVBoxLayout()
        self.MM2layout = QVBoxLayout()
        self.MR2layout = QVBoxLayout()
        self.MMT2layout = QHBoxLayout()
        self.MMB2layout = QHBoxLayout()
        self.form1layout = QFormLayout()
        self.form2layout = QFormLayout()
        self.ML2layout.addWidget(self.companyname)
        self.ML2layout.addWidget(self.ADDbtn)
        self.ML2layout.addWidget(self.PRINTbtn)
        self.ML2layout.addWidget(self.DELETEbtn)
        self.ML2layout.setContentsMargins(0,0,0,500)
        self.MM2layout.addWidget(self.datetable)
        self.MM2layout.heightForWidth(20)
        self.MR2layout.addWidget(self.reporttable)
        self.form1layout.addRow(QLabel("black and white :"), self.BW)
        self.form1layout.addRow(QLabel("large black and white : "),self.BL )
        self.form1layout.addRow(QLabel("TOTAL :"), self.Total)
        self.form1layout.addRow(QLabel("K :"), self.K)
        self.form1layout.addRow(QLabel("C :"), self.C)
        self.form1layout.addRow(QLabel("M :"), self.M)
        self.form1layout.addRow(QLabel("Y :"), self.Y)
        self.form1layout.addRow(QLabel("R1 :"), self.R1)
        self.form1layout.addRow(QLabel("R2 :"), self.R2)
        self.form1layout.addRow(QLabel("R3 :"), self.R3)
        self.form1layout.addRow(QLabel("R4 :"), self.R4)
        self.form2layout.addRow(QLabel("Color :"), self.Color)
        self.form2layout.addRow(QLabel("large color :"), self.CL)
        self.form2layout.addRow(QLabel("    "), QLabel("   "))
        self.form2layout.addRow(QLabel("chip part number :"),self.kchip )
        self.form2layout.addRow(QLabel("chip part number :"), self.cchip)
        self.form2layout.addRow(QLabel("chip part number :"), self.mchip)
        self.form2layout.addRow(QLabel("chip part number :"), self.ychip)
        self.form2layout.addRow(QLabel("chip part number :"), self.r1chip)
        self.form2layout.addRow(QLabel("chip part number :"), self.r2chip)
        self.form2layout.addRow(QLabel("chip part number :"), self.r3chip)
        self.form2layout.addRow(QLabel("chip part number :"), self.r4chip)
        self.MMT2layout.setContentsMargins(0,0,0,50)
        self.MMB2layout.addLayout(self.form1layout)
        self.MMB2layout.addLayout(self.form2layout)
        self.MM2layout.addLayout(self.MMB2layout)
        self.MM2layout.addLayout(self.MMT2layout)
        self.M2layout.addLayout(self.ML2layout)
        self.M2layout.addLayout(self.MM2layout)
        self.M2layout.addLayout(self.MR2layout)
        self.tab2.setLayout(self.M2layout)
        #-----------------------------------------tab3-----------------------------------------
        self.M3layout = QHBoxLayout()
        self.ML3layout = QVBoxLayout()
        self.MR3layout = QVBoxLayout()
        self.L3layout = QVBoxLayout()
        self.RT3layout  = QHBoxLayout()
        self.RB3layout = QHBoxLayout()
        self.ML3groupbox = QGroupBox("Member's List")
        self.RT3groupbox = QGroupBox('Search')
        self.RB3groupbox = QGroupBox()
        self.L3layout.addWidget(self.membertable)
        self.ML3groupbox.setLayout(self.L3layout)
        self.RT3layout.addWidget(self.searchmemberentry)
        self.RT3layout.addWidget(self.shbtn)
        self.RT3groupbox.setLayout(self.RT3layout)
        self.RB3layout.addWidget(self.addmembers)
        self.RB3layout.addWidget(self.prntbtn)
        self.RB3layout.addWidget(self.Deletebtn)
        self.RB3groupbox.setLayout(self.RB3layout)
        self.MR3layout.addWidget(self.RT3groupbox , 20)
        self.MR3layout.addWidget(self.RB3groupbox , 80)
        self.RB3groupbox.setContentsMargins(0,0,0,140)
        self.M3layout.addWidget(self.ML3groupbox , 75)
        self.M3layout.addLayout(self.MR3layout , 25)
        self.tab3.setLayout(self.M3layout)
        
    def displayproducts(self):
        for i in reversed(range(self.ptable.rowCount())):
            self.ptable.removeRow(i)
        query = Cursor.execute('SELECT * FROM products')
        for rowdata in query:
            rownum = self.ptable.rowCount()
            self.ptable.insertRow(rownum)
            for columnnum, data in enumerate(rowdata):
                self.ptable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
        self.ptable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
    def addpage(self):
        self.Addpage =  addproduct.addproducts()
        
    def searchproduct(self):
        pname = self.psearchentry.text()
        self.psearchentry.setText('')
        if pname =='':
            QMessageBox.warning(self, 'Warning', 'Search box can not be empty')
        else:
            query = 'SELECT * FROM products WHERE p_name LIKE ?'
            result = Cursor.execute(query, ('%' + pname + '%',)).fetchall()
            if  result == []:
                QMessageBox.warning(self, 'Warning', 'There is no such a product')
            else:
                for i in reversed(range(self.ptable.rowCount())):
                    self.ptable.removeRow(i)
                for rowdata in result:
                    rownum = self.ptable.rowCount()
                    self.ptable.insertRow(rownum)
                    for columnnum, data in enumerate(rowdata):
                        self.ptable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
                self.ptable.setEditTriggers(QAbstractItemView.NoEditTriggers)
    
    def logout(self):
        self.loginpage = login_page.login()
        self.close()
    
    def filterp(self):
        quality = self.qualitybox.currentText()
        available = self.availablebox.currentText()
        result = Cursor.execute('SELECT * FROM products WHERE p_quality LIKE ?  AND p_availability LIKE ?', ('%'+quality+'%', '%'+available+'%')).fetchall()
        if result==[]:
            QMessageBox.information(self, 'warning', 'Nothing found')
        else:
            for i in reversed(range(self.ptable.rowCount())):
                    self.ptable.removeRow(i)
            for rowdata in result:
                rownum = self.ptable.rowCount()
                self.ptable.insertRow(rownum)
                for columnnum, data in enumerate(rowdata):
                    self.ptable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
            self.ptable.setEditTriggers(QAbstractItemView.NoEditTriggers)
            
    def resetlist(self):
        self.displayproducts()
    
    def companeyList(self):
        query = Cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
        listc = []
        for name in query :
            listc.append(name[0])
        for i in range(3, len(listc)):
            self.companyname.addItem(listc[i])
            
    def displaydate(self):
        companeyname = self.companyname.currentText()
        if companeyname == '--Company List--' :
            pass
        else:
            for i in reversed(range(self.datetable.rowCount())):
                self.datetable.removeRow(i)
            query = Cursor.execute(f'''SELECT id, service_date, tech_name, p_serialnum, p_model FROM [{companeyname}]''')
            for rowdata in query:
                rownum = self.datetable.rowCount()
                self.datetable.insertRow(rownum)
                for columnnum, data in enumerate(rowdata):
                    self.datetable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
            self.datetable.setEditTriggers(QAbstractItemView.NoEditTriggers)
            
    def rowclick(self):
        reportlist = []
        for i in range(0,2):
            reportlist.append(self.datetable.item(self.datetable.currentRow(), i).text())
        reportid = reportlist[0]
        companeyname = self.companyname.currentText()
        for i in reversed(range(self.reporttable.rowCount())):
            self.reporttable.removeRow(i)
        query = Cursor.execute(f'''SELECT id, s_report FROM [{companeyname}] WHERE id = ? ''' , (reportid,))
        for rowdata in query:
            rownum = self.reporttable.rowCount()
            self.reporttable.insertRow(rownum)
            for columnnum, data in enumerate(rowdata):
                self.reporttable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
        self.reporttable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.devicedetail()
    
    def devicedetail(self):
        global detail , Dquery
        detail = []
        for i in range(0,2):
            detail.append(self.datetable.item(self.datetable.currentRow(), i).text())
        detailid = detail[0]
        companeyname = self.companyname.currentText()
        Dquery= Cursor.execute(f'''SELECT * FROM [{companeyname}] WHERE id = ? ''' , (detailid,)).fetchall()
        print(Dquery)
        self.BW.setText(Dquery[0][12])
        self.Color.setText(Dquery[0][13])
        self.BL.setText(Dquery[0][15])
        self.CL.setText(Dquery[0][16])
        self.Total.setText(Dquery[0][14])
        self.K.setText(Dquery[0][18])
        self.C.setText(Dquery[0][19])
        self.M.setText(Dquery[0][20])
        self.Y.setText(Dquery[0][21])
        self.kchip.setText(Dquery[0][22])
        self.cchip.setText(Dquery[0][23])
        self.mchip.setText(Dquery[0][24])
        self.ychip.setText(Dquery[0][25])
        self.R1.setText(Dquery[0][26])
        self.R2.setText(Dquery[0][27])
        self.R3.setText(Dquery[0][28])
        self.R4.setText(Dquery[0][29])
        self.r1chip.setText(Dquery[0][30])
        self.r2chip.setText(Dquery[0][30])
        self.r3chip.setText(Dquery[0][30])
        self.r4chip.setText(Dquery[0][30])
    
    def preport(self):
            fn, _ = QFileDialog.getSaveFileName(
            self, "Export PDF", None, "PDF files (.pdf);;All Files()"
            )
            if fn:
                if QFileInfo(fn).suffix() == "":
                    fn += ".pdf"
                print_widget(self.reporttable, fn)
                
    def deletereport(self):
        detail = []
        for i in range(0,2):
            detail.append(self.datetable.item(self.datetable.currentRow(), i).text())
        reportid = detail[0]
        companeyname = self.companyname.currentText()
        Cursor.execute(f'''DELETE FROM [{companeyname}] WHERE id = ? ''' , (reportid,))
        Connection.commit()
        self.displaydate()
                
    def printreport(self):
            fn, _ = QFileDialog.getSaveFileName(
            self, "Export PDF", None, "PDF files (.pdf);;All Files()"
            )
            if fn:
                if QFileInfo(fn).suffix() == "":
                    fn += ".pdf"
                print_widget(self.ptable, fn)
    
    def newdevice(self):
        self.new = add.new()

    def displaymembers(self):
        for i in reversed(range(self.membertable.rowCount())):
            self.membertable.removeRow(i)
        query = Cursor.execute('SELECT * FROM members')
        for rowdata in query:
            rownum = self.membertable.rowCount()
            self.membertable.insertRow(rownum)
            for columnnum, data in enumerate(rowdata):
                self.membertable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
        self.membertable.setEditTriggers(QAbstractItemView.NoEditTriggers)
    
    def searchmember(self):
        membername = self.searchmemberentry.text()
        self.searchmemberentry.setText('')
        if membername =='':
            QMessageBox.warning(self, 'Warrning' , 'Search box can not be EMPTY')
        else:
            result = Cursor.execute('SELECT * FROM members WHERE first_name OR last_name LIKE ?' , ('%'+membername+'%',)).fetchall()
            if result == []:
                QMessageBox.warning(self, 'Warning', 'There is no such member')
            else:
                for i in reversed(range(self.membertable.rowCount())):
                    self.membertable.removeRow(i)
                for rowdata in result:
                    rownum = self.membertable.rowCount()
                    self.membertable.insertRow(rownum)
                    for columnnum, data in enumerate(rowdata):
                        self.membertable.setItem(rownum, columnnum,QTableWidgetItem(str(data)))
                self.membertable.setEditTriggers(QAbstractItemView.NoEditTriggers)
    
    def addmember(self):
        pass
    
    def printmemberlist(self):
        pass
    
    def deletmember(self):
        pass
    