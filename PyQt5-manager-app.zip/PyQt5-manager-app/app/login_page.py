import sqlite3
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import *

import admin_mainpage
import user_mainpage

Connection = sqlite3.connect('DataBase.db')
Cursor = Connection.cursor()

class login(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Part.co")
        self.setGeometry(580,300,350,200)
        self.UI()
        self.show()
    
    def UI(self):
        self.widgets()
        self.layout()
        self.adminsetting()
        
    def widgets(self):
        self.img = QLabel('LOGIN')
        self.img.setStyleSheet('font-size:20pt')
        self.usernamelabel = QLabel('Username :')
        self.passwordlabel = QLabel('Password :')
        self.userentry = QLineEdit()
        self.passentry = QLineEdit()
        self.userentry.setPlaceholderText('Enter your username ')
        self.passentry.setPlaceholderText('Enter your password ')
        self.passentry.setEchoMode(QLineEdit.Password)
        self.loginbtn =QPushButton('Login')
        self.loginbtn.clicked.connect(self.login)
    
    def layout(self):
        self.Mlayout = QVBoxLayout()
        self.MTlayout = QHBoxLayout()
        self.MBlayout = QFormLayout()
        self.MTlayout.addWidget(self.img)
        self.MTlayout.setAlignment(Qt.AlignCenter)
        self.MBlayout.addRow(self.usernamelabel, self.userentry)
        self.MBlayout.addRow(self.passwordlabel, self.passentry)
        self.MBlayout.addRow('', self.loginbtn)
        self.Mlayout.addLayout(self.MTlayout)
        self.Mlayout.addLayout(self.MBlayout)
        self.setLayout(self.Mlayout)
        
    def adminsetting(self):    
        global adminusername , adminpassword
        adminusername = 'administrator'
        adminpassword = '1111'
        adminid = 1
        adminchecked = Cursor.execute('SELECT username , pssword FROM members WHERE id = ?' , (adminid,)).fetchall()
        if adminchecked == []:
            admin = Cursor.execute('INSERT INTO members (username , pssword) VALUES (?,?)' , (adminusername , adminpassword))
            Connection.commit()
            
    def login(self):
        USERNAME = self.userentry.text()
        PSSWORD = self.passentry.text()
        if USERNAME =='' or PSSWORD == '':
            QMessageBox.information(self, ' Warrning', 'Fill the boxes')
        else:
            userquery = 'SELECT id , username FROM members WHERE username LIKE ?'
            passquery = 'SELECT id , pssword FROM members WHERE id LIKE ? and pssword LIKE ?'
            user = Cursor.execute(userquery, ('%'+USERNAME+'%',)).fetchall()
            if user == []:
                QMessageBox.information(self, 'Warrning', 'Username is invalid')
            else:
                psswd = Cursor.execute(passquery, ('%'+ str(user[0][0]) +'%' , '%'+ PSSWORD +'%')).fetchall()
                print(psswd)
                if psswd == []:
                    QMessageBox.information(self, 'Warrning', 'Password is invalid')
                else:
                    if USERNAME == adminusername and PSSWORD == adminpassword :
                        self.newpage = admin_mainpage.adminpage()
                        self.close()
                    else:
                        self.newpage = user_mainpage.userpage()
                        self.close()
        
        
    
def main():
    app = QApplication(sys.argv)
    win = login()
    sys.exit(app.exec_())
    
if __name__=="__main__":
    main()