import sqlite3
import sys

from PyQt5.QtWidgets import *

import admin_mainpage

Connection = sqlite3.connect('DataBase.db')
Cursor = Connection.cursor()

class new(QWidget):
    def __init__ (self):
        super().__init__()
        self.setWindowTitle('Add New Device or New Companey')
        self.setGeometry(400,250,600,400)
        self.UI()
        self.show()
        
    def UI(self):
        self.widgets()
        self.layout()
        self.companeyList()
        
    def widgets(self):
        self.text1 = QLabel('*For Adding New Companey Press "Companey"')
        self.text2 = QLabel('*For Adding New Device  Choose The Companey From The List and Press "Device"')
        self.ComList = QComboBox()
        self.ComList.addItem('--Companey--')
        self.companeybtn = QPushButton('Companey')
        self.companeybtn.clicked.connect(self.newpage1)
        self.devicebtn = QPushButton('Device')
        self.devicebtn.clicked.connect(self.newpage2)
    
    def layout(self):
        Mlayout = QVBoxLayout()
        MTlayout = QVBoxLayout()
        MBlayout = QHBoxLayout()
        MTlayout.addWidget(self.text1)
        MTlayout.addWidget(self.text2)
        MTlayout.addWidget(self.ComList)
        MTlayout.setContentsMargins(30,50,0,0)
        MBlayout.addWidget(self.companeybtn)
        MBlayout.addWidget(self.devicebtn)
        MBlayout.setContentsMargins(100,50,100,70)
        Mlayout.addLayout(MTlayout)
        Mlayout.addLayout(MBlayout)
        self.setLayout(Mlayout)
        
    def companeyList(self):
        query = Cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
        listc = []
        for name in query :
            listc.append(name[0])
        for i in range(3, len(listc)):
            self.ComList.addItem(listc[i])

    def newpage1(self):
        self.np = newcompaney()
        self.close()
        
    def newpage2(self):
        global comlist 
        comlist = self.ComList.currentText()
        self.np = newdevice()
        self.close()

class newcompaney(QWidget):
    def __init__(self) :
        super().__init__()
        self.setWindowTitle('New Company')
        self.setGeometry(400,250,600,400)
        self.UI()
        self.show()
        
    def UI(self):
        self.widgets()
        self.layout()
    
    def widgets(self):
        self.setStyleSheet('font-size:15pt')
        self.Cname = QLabel('Company Name :')
        self.notrp = QLabel('responsible person :')
        self.address = QLabel('Company Address :')
        self.phonenum1 = QLabel('Phone Number - 1 :')
        self.phonenum2 = QLabel('Phone Number - 2 :')
        self.phonenum3 = QLabel('Phone Number - 3 :')
        self.nameE = QLineEdit()
        self.notrpE = QLineEdit()
        self.addressE = QLineEdit()
        self.phn1E = QLineEdit()
        self.phn2E = QLineEdit()
        self.phn3E = QLineEdit()
        self.nextbtn = QPushButton('Add')
        self.nextbtn.clicked.connect(self.createcompanydb)
        self.backbtn = QPushButton('Back')
        self.backbtn.clicked.connect(self.backword)
        self.closebtn = QPushButton('Close')
        self.closebtn.clicked.connect(self.Close)
    
    def layout(self):
        self.Mlayout = QVBoxLayout()
        self.MTlayout = QFormLayout()
        self.MBlayout = QHBoxLayout()
        self.MTlayout.addRow(self.Cname , self.nameE)
        self.MTlayout.addRow(self.notrp , self.notrpE)
        self.MTlayout.addRow(self.address , self.addressE)
        self.MTlayout.addRow(self.phonenum1 , self.phn1E)
        self.MTlayout.addRow(self.phonenum2 , self.phn2E)
        self.MTlayout.addRow(self.phonenum3 , self.phn3E)
        self.MTlayout.setContentsMargins(0,50,81,0)
        self.MBlayout.addWidget(self.nextbtn)
        self.MBlayout.addWidget(self.backbtn)
        self.MBlayout.addWidget(self.closebtn)
        self.MBlayout.setContentsMargins(250,0,0,0)
        self.Mlayout.addLayout(self.MTlayout)
        self.Mlayout.addLayout(self.MBlayout)
        self.setLayout(self.Mlayout)
    
    def createcompanydb(self):
        global cname, cadmin ,caddress ,ph1 ,ph2 ,ph3
        cname = self.nameE.text()
        if cname =='':
            QMessageBox.warning(self, 'Warrning', 'Enter the company name')
        else:
            table = f""" CREATE TABLE  IF NOT EXISTS [{cname}] (
                        "id" INTEGER,
                        "adminname" TEXT,
                        "caddress" TEXT,
                        "cphone1" TEXT,
                        "cphone2" TEXT,
                        "cphone3" TEXT,
                        "p_section" TEXT,
                        "p_model" TEXT,
                        "p_serialnum" TEXT,
                        "tech_name" TEXT,
                        "installation_date" TEXT,
                        "service_date" TEXT,
                        "bw_count" TEXT,
                        "c_count" TEXT,
                        "total_count" TEXT,
                        "bwl_count" TEXT,
                        "cl_count" TEXT,
                        "s_report" TEXT,
                        "k" TEXT,
                        "c" TEXT,
                        "m" TEXT,
                        "y" TEXT,
                        "kpart" TEXT,
                        "cpart" TEXT,
                        "mpart" tEXT,
                        "ypart" TEXT,
                        "r1" TEXT,
                        "r2" TEXT,
                        "r3" TEXT,
                        "r4" TEXT,
                        "rpart" TEXT,
                        "fuser" TEXT,
                        "fuserpart" TEXT,
                        PRIMARY KEY("id" AUTOINCREMENT)
            );""" 
            Cursor.execute(table)
            
        cadmin = self.notrpE.text()
        caddress = self.addressE.text()
        ph1 = self.phn1E.text()
        ph2 = self.phn2E.text()
        ph3 = self.phn3E.text()
        if cadmin=='' or caddress=='' or ph1 =='':
            QMessageBox.warning(self, 'Warrning', 'Enter company details ')
        else:
            query = f'''INSERT INTO [{cname}](adminname, caddress, cphone1, cphone2, cphone3) VALUES (?,?,?,?,?)'''
            Cursor.execute(query, (cadmin, caddress, ph1, ph2, ph3))
            Connection.commit()
            self.newpage = admin_mainpage.adminpage()
            self.close()
            
    def backword(self):
        self.np = new()
        self.close()
                
    def Close(self):
        self.close()
    
class newdevice(QWidget):
    def __init__(self) :
        super().__init__()
        self.setWindowTitle('New Device')
        self.setGeometry(400,250,600,400)
        self.UI()
        self.show()
        
    def UI(self):
        self.widgets()
        self.layout()
    
    def widgets(self):
        self.section  =QLabel('Section')
        self.model  =QLabel('Model')
        self.SN  =QLabel('Serial Number')
        self.inastaldate  =QLabel('Installation Date')
        self.bw_count  =QLabel('BW Counter')
        self.c_count  =QLabel('Color Counter')
        self.total_count  =QLabel('Total Counter')
        self.bwl_count  =QLabel('BW Large Counter')
        self.cl_count  =QLabel('Color Large Counter')
        self.K  =QLabel('K Toner')
        self.C  =QLabel('C Toner')
        self.M  =QLabel('M Toner')
        self.Y  =QLabel('Y Toner')
        self.kpart  =QLabel('K Part Number')
        self.cpart  =QLabel('C Part Number')
        self.mpart  =QLabel('M Part Number')
        self.ypart  =QLabel('Y Part Number')
        self.r1  =QLabel('Drum R1')
        self.r2  =QLabel('Drum R2')
        self.r3  =QLabel('Drum R3')
        self.r4  =QLabel('Drum R4')
        self.rpart  =QLabel('Drum Part Number')
        self.fuser  =QLabel('Fuser')
        self.fuserpart  =QLabel('Fuser Part number')
        self.sectionE  =QLineEdit()
        self.modelE =QLineEdit()
        self.SNE  =QLineEdit()
        self.inastaldateE  =QLineEdit()
        self.bw_countE  =QLineEdit()
        self.c_countE  =QLineEdit()
        self.total_countE  =QLineEdit()
        self.bwl_countE  =QLineEdit()
        self.cl_countE  =QLineEdit()
        self.KE  =QLineEdit()
        self.CE  =QLineEdit()
        self.ME  =QLineEdit()
        self.YE  =QLineEdit()
        self.kpartE  =QLineEdit()
        self.cpartE  =QLineEdit()
        self.mpartE  =QLineEdit()
        self.ypartE  =QLineEdit()
        self.r1E  =QLineEdit()
        self.r2E  =QLineEdit()
        self.r3E  =QLineEdit()
        self.r4E  =QLineEdit()
        self.rpartE  =QLineEdit()
        self.fuserE  =QLineEdit()
        self.fuserpartE  =QLineEdit()
        self.nextbtn = QPushButton('Next')
        self.nextbtn.clicked.connect(self.companydata) 
        self.backbtn = QPushButton('Back')
        self.backbtn.clicked.connect(self.backword) 
        self.closebtn = QPushButton('Close')
        self.closebtn.clicked.connect(self.Close) 

    def layout(self):
        self.Mlayout = QVBoxLayout()
        self.TMlayout = QHBoxLayout()
        self.BMlayout = QHBoxLayout()
        self.TLlayout = QFormLayout()
        self.TMIDlayout = QFormLayout()
        self.TRlayout = QFormLayout()
        self.TLlayout.addRow(self.section , self.sectionE)
        self.TLlayout.addRow(self.model , self.modelE)
        self.TLlayout.addRow(self.SN , self.SNE)
        self.TLlayout.addRow(self.inastaldate , self.inastaldateE)
        self.TLlayout.addRow(self.bw_count , self.bw_countE)
        self.TLlayout.addRow(self.c_count , self.c_countE)
        self.TLlayout.addRow(self.total_count , self.total_countE) 
        self.TLlayout.addRow(self.bwl_count , self.bwl_countE)
        self.TMIDlayout.addRow(self.cl_count, self.cl_countE)
        self.TMIDlayout.addRow(self.K , self.KE)
        self.TMIDlayout.addRow(self.M , self.ME)
        self.TMIDlayout.addRow(self.kpart , self.kpartE)
        self.TMIDlayout.addRow(self.mpart , self.mpartE)
        self.TMIDlayout.addRow(self.r1 , self.r1E)
        self.TMIDlayout.addRow(self.r3 , self.r3E)
        self.TMIDlayout.addRow(self.rpart , self.rpartE)
        self.TRlayout.addRow(self.fuser , self.fuserE)
        self.TRlayout.addRow(self.C , self.CE)
        self.TRlayout.addRow(self.Y , self.YE)
        self.TRlayout.addRow(self.cpart , self.cpartE)
        self.TRlayout.addRow(self.ypart , self.ypartE)
        self.TRlayout.addRow(self.r2 , self.r2E)
        self.TRlayout.addRow(self.r4 , self.r4E)
        self.TRlayout.addRow(self.fuserpart , self.fuserpartE)
        self.BMlayout.addWidget(self.nextbtn)
        self.BMlayout.addWidget(self.backbtn)
        self.BMlayout.addWidget(self.closebtn)
        self.BMlayout.setContentsMargins(250,0,0,0)
        self.TMlayout.addLayout(self.TLlayout)
        self.TMlayout.addLayout(self.TMIDlayout)
        self.TMlayout.addLayout(self.TRlayout)
        self.Mlayout.addLayout(self.TMlayout)
        self.Mlayout.addLayout(self.BMlayout)
        self.setLayout(self.Mlayout)
    
    def companydata(self):
        if self.sectionE.text() == '' or self.modelE.text() =='' or self.SNE.text() =='':
            QMessageBox.warning(self , 'Warrning' , ' Please write Section , Model and Serial Number of the Device')
        else:
            global a,b,c,d,e,f,g,h,i,j,k,l,m,o,p,q,r,s,t,u,v,w,x,y
            a = self.sectionE.text()  
            b = self.modelE.text()  
            c = self.SNE.text() 
            d = self.inastaldateE.text()  
            e = self.bw_countE.text() 
            f = self.c_countE.text() 
            g = self.total_countE.text() 
            h = self.bwl_countE.text()
            i = self.cl_countE.text()  
            j = self.KE.text() 
            k = self.CE.text() 
            l = self.ME.text() 
            m = self.YE.text() 
            o = self.kpartE.text() 
            p = self.cpartE.text() 
            q = self.mpartE.text() 
            r = self.ypartE.text() 
            s = self.r1E.text() 
            t = self.r2E.text() 
            u = self.r3E.text() 
            v = self.r4E.text() 
            w = self.rpartE.text() 
            x = self.fuserE.text() 
            y = self.fuserpartE.text()
            self.np = report()
            self.close()
    
    def backword(self):
        self.np = new()
        self.close()
    
    def Close(self):
        self.close()
     
class report(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Report')
        self.setGeometry(400,250,600,400)
        self.UI()
        self.show()
        
    def UI(self):
        self.widgets()
        self.layout()
        
    def widgets(self):
        self.servicedate = QLabel ('Date')
        self.tech = QLabel('Technician Name')
        self.servicedateE = QLineEdit()
        self.techE = QLineEdit()
        self.report = QTextEdit('Report')
        self.savebtn = QPushButton('Save')
        self.savebtn.clicked.connect(self.finalsave)
        self.backbtn = QPushButton('Back')
        self.backbtn.clicked.connect(self.backword) 
        self.closebtn = QPushButton('Close')
        self.closebtn.clicked.connect(self.Close)
    
    def layout(self):
        self.Mlayout = QVBoxLayout()
        self.TMlayout = QHBoxLayout()
        self.MMlayout = QHBoxLayout()
        self.BMlayout = QHBoxLayout()
        self.TMlayout.addWidget(self.servicedate)
        self.TMlayout.addWidget(self.servicedateE)
        self.TMlayout.addWidget(self.tech)
        self.TMlayout.addWidget(self.techE)
        self.MMlayout.addWidget(self.report)
        self.BMlayout.addWidget(self.savebtn)
        self.BMlayout.addWidget(self.backbtn)
        self.BMlayout.addWidget(self.closebtn)
        self.BMlayout.setContentsMargins(250,0,0,0)
        self.Mlayout.addLayout(self.TMlayout)
        self.Mlayout.addLayout(self.MMlayout)
        self.Mlayout.addLayout(self.BMlayout)
        self.setLayout(self.Mlayout)
    
    def finalsave(self):
        if self.servicedateE.text() =='' or self.techE.text() == '' or self.report.toPlainText() == '' :
            QMessageBox.warning(self , 'Warning' , ' Please Fill the boxes')
        else:
            query1 = f'''SELECT adminname, caddress, cphone1, cphone2, cphone3 FROM [{comlist}] WHERE id = ?'''
            B = Cursor.execute(query1, ('1',)).fetchall()
            cadmin = B[0][0]
            caddress = B[0][1]
            ph1 = B[0][2]
            ph2 = B[0][3]
            ph3 = B[0][4]
            query2= f'''INSERT INTO [{comlist}](adminname, caddress, cphone1, cphone2, cphone3 , p_section , p_model , p_serialnum , 
                                                                        installation_date , bw_count , c_count , total_count , bwl_count ,  cl_count , k ,c , m , y , 
                                                                        kpart , cpart , mpart , ypart ,r1 , r2 , r3 , r4 , rpart , fuser , fuserpart , tech_name , service_date ,
                                                                        s_report) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'''
            Cursor.execute(query2, (cadmin, caddress, ph1, ph2, ph3 , a,b,c,d,e,f,g,h,i,j,k,l,m,o,p,q,r,s,t,u,v,w,x,y ,self.techE.text(), self.servicedateE.text(), self.report.toPlainText()))
            Connection.commit()
            self.np = admin_mainpage.adminpage()
            self.close()
    
    
    def backword(self):
        self.np = newdevice()
        self.close()
    
    def Close(self):
        self.close()
